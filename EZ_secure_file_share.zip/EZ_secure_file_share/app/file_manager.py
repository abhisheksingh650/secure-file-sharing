import os
from fastapi import UploadFile
from config import ALLOWED_EXTENSIONS, UPLOAD_FOLDER
from uuid import uuid4

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return filename.split(".")[-1] in ALLOWED_EXTENSIONS

def save_file(file: UploadFile):
    ext = file.filename.split(".")[-1]
    new_filename = f"{uuid4().hex}.{ext}"
    file_location = os.path.join(UPLOAD_FOLDER, new_filename)
    with open(file_location, "wb") as f:
        f.write(file.file.read())
    return new_filename, file_location