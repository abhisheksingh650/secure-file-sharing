from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models import User, File
from app.schemas import UserCreate, UserLogin, FileOut
from app.utils import get_password_hash, verify_password, create_encrypted_url, decode_encrypted_url
from app.auth import create_access_token
from datetime import timedelta
from config import ACCESS_TOKEN_EXPIRE_MINUTES

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/client/signup")
def signup(data: UserCreate, db: Session = Depends(get_db)):
    hashed_pwd = get_password_hash(data.password)
    user = User(email=data.email, hashed_password=hashed_pwd, is_client=True, is_verified=True)
    db.add(user)
    db.commit()
    enc_url = create_encrypted_url({"email": data.email})
    return {"message": "Registered", "encrypted_url": f"/client/verify/{enc_url}"}

@router.post("/client/login")
def login(data: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email, User.is_client == True).first()
    if not user or not verify_password(data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Invalid Credentials")
    token = create_access_token({"sub": user.email}, timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    return {"access_token": token}

@router.get("/client/files", response_model=list[FileOut])
def list_files(db: Session = Depends(get_db)):
    files = db.query(File).all()
    return files

@router.get("/client/download/{file_id}")
def get_download_link(file_id: int, db: Session = Depends(get_db)):
    file = db.query(File).filter(File.id == file_id).first()
    if not file:
        raise HTTPException(status_code=404, detail="File not found")
    token = create_encrypted_url({"file_id": file_id})
    return {"download_link": f"/client/download-file/{token}"}

@router.get("/client/download-file/{token}")
def download_file(token: str, db: Session = Depends(get_db)):
    data = decode_encrypted_url(token)
    if not data:
        raise HTTPException(status_code=403, detail="Invalid or expired link")
    file = db.query(File).filter(File.id == data.get("file_id")).first()
    if not file:
        raise HTTPException(status_code=404, detail="File not found")
    return {"file_path": file.filepath, "filename": file.filename}