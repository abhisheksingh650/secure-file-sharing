from fastapi import APIRouter, Depends, UploadFile, HTTPException, status
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.models import User, File
from app.schemas import UserLogin
from app.utils import verify_password
from app.auth import create_access_token
from app.file_manager import allowed_file, save_file
from datetime import timedelta
from config import ACCESS_TOKEN_EXPIRE_MINUTES

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/ops/login")
def ops_login(data: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email, User.is_client == False).first()
    if not user or not verify_password(data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Invalid Credentials")
    token = create_access_token({"sub": user.email}, timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    return {"access_token": token}

@router.post("/ops/upload")
def upload_file(file: UploadFile, db: Session = Depends(get_db)):
    if not allowed_file(file.filename):
        raise HTTPException(status_code=400, detail="Invalid file type")
    filename, path = save_file(file)
    db_file = File(filename=filename, filepath=path, uploaded_by=1)  # hardcoded user for demo
    db.add(db_file)
    db.commit()
    return {"message": "File uploaded successfully"}