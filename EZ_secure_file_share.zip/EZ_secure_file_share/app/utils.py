from passlib.context import CryptContext
from itsdangerous import URLSafeTimedSerializer
from config import SECRET_KEY

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
s = URLSafeTimedSerializer(SECRET_KEY)

def get_password_hash(password):
    return pwd_context.hash(password)

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def create_encrypted_url(data):
    return s.dumps(data, salt="secure-download")

def decode_encrypted_url(token, max_age=3600):
    from itsdangerous import BadSignature, SignatureExpired
    try:
        return s.loads(token, salt="secure-download", max_age=max_age)
    except (BadSignature, SignatureExpired):
        return None
