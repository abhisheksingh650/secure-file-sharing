import os
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./fileshare.db")
SECRET_KEY = os.getenv("SECRET_KEY", "supersecret")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30
UPLOAD_FOLDER = "static/uploads"
ALLOWED_EXTENSIONS = {"pptx", "docx", "xlsx"}
EMAIL_SENDER = "your_email@example.com"